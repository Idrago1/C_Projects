#include <iostream>
#include "Node.h"

using namespace std;


bool Node::hasTwoStrings() const{
    return large!="";
}